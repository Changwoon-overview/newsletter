<?php
/**
 * Plugin Name: AI Newsletter Generator Pro
 * Plugin URI: https://example.com/ai-newsletter-generator-pro
 * Description: WordPress 게시물을 AI가 분석하여 자동으로 뉴스레터를 생성하고 발송하는 통합 솔루션입니다.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ai-newsletter-generator-pro
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// 직접 접근 방지 - 보안 강화
if (!defined('ABSPATH')) {
    exit('Direct access not allowed.');
}

// PHP 메모리 제한 증가 - 500 오류 방지
@ini_set('memory_limit', '512M');
@ini_set('max_execution_time', 300);

// 플러그인 상수 정의
define('AINL_PLUGIN_FILE', __FILE__);
define('AINL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AINL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AINL_PLUGIN_VERSION', '1.0.0');
define('AINL_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * AI Newsletter Generator Pro 메인 클래스
 * 플러그인의 초기화와 전체적인 관리를 담당합니다.
 */
class AI_Newsletter_Generator_Pro {
    
    /**
     * 싱글톤 인스턴스
     */
    private static $instance = null;
    
    /**
     * 싱글톤 패턴으로 인스턴스 반환
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * 생성자 - 플러그인 초기화
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * WordPress 훅 초기화
     */
    private function init_hooks() {
        // 플러그인 활성화/비활성화 훅
        register_activation_hook(AINL_PLUGIN_FILE, array($this, 'activate'));
        register_deactivation_hook(AINL_PLUGIN_FILE, array($this, 'deactivate'));
        
        // 플러그인 삭제 훅
        register_uninstall_hook(AINL_PLUGIN_FILE, array('AI_Newsletter_Generator_Pro', 'uninstall'));
        
        // 플러그인 로드 후 초기화
        add_action('plugins_loaded', array($this, 'init'));
        
        // 크론 스케줄 추가
        add_filter('cron_schedules', array($this, 'add_cron_schedules'));
        
        // 관리자 초기화
        if (is_admin()) {
            add_action('admin_init', array($this, 'admin_init'));
        }
    }
    
    /**
     * 의존성 파일 로드
     */
    private function load_dependencies() {
        // 오토로더 설정
        spl_autoload_register(array($this, 'autoload'));
        
        // 핵심 클래스 로드
        require_once AINL_PLUGIN_DIR . 'includes/class-ainl-activator.php';
        require_once AINL_PLUGIN_DIR . 'includes/class-ainl-deactivator.php';
        require_once AINL_PLUGIN_DIR . 'includes/class-ainl-database.php';
    }
    
    /**
     * 클래스 오토로더
     * 클래스명을 기반으로 파일을 자동 로드합니다.
     */
    public function autoload($class_name) {
        // 플러그인 클래스만 처리
        if (strpos($class_name, 'AINL_') !== 0) {
            return;
        }
        
        // 클래스명을 파일명으로 변환
        $file_name = 'class-' . strtolower(str_replace('_', '-', $class_name)) . '.php';
        
        // 여러 디렉토리에서 파일 검색
        $search_paths = array(
            AINL_PLUGIN_DIR . 'includes/',
            AINL_PLUGIN_DIR . 'admin/',
            AINL_PLUGIN_DIR . 'public/'
        );
        
        foreach ($search_paths as $path) {
            $file_path = $path . $file_name;
            if (file_exists($file_path)) {
                require_once $file_path;
                return;
            }
        }
    }
    
    /**
     * 플러그인 초기화
     */
    public function init() {
        // 텍스트 도메인 로드
        load_plugin_textdomain(
            'ai-newsletter-generator-pro',
            false,
            dirname(AINL_PLUGIN_BASENAME) . '/languages'
        );
        
        // 플러그인이 활성화된 경우에만 실행
        if (get_option('ainl_plugin_activated')) {
            $this->init_plugin_components();
        }
    }
    
    /**
     * 관리자 초기화
     */
    public function admin_init() {
        // 관리자 관련 초기화 작업
        if (current_user_can('manage_options')) {
            // 관리자 메뉴 및 페이지 초기화는 다음 작업에서 구현
        }
    }
    
    /**
     * 플러그인 컴포넌트 초기화
     */
    private function init_plugin_components() {
        // WordPress 환경 체크
        if (!function_exists('add_action') || !function_exists('is_admin')) {
            return;
        }
        
        // 기본 시스템만 우선 초기화 (오류 방지)
        try {
            // 보안 시스템 초기화 (최우선)
            if (class_exists('AINL_Security')) {
                new AINL_Security();
            }
            
            // 데이터베이스 관리자 초기화
            if (class_exists('AINL_Database')) {
                new AINL_Database();
            }
            
            // 구독자 관리자 초기화
            if (class_exists('AINL_Subscriber_Manager')) {
                new AINL_Subscriber_Manager();
            }
            
            // 이메일 매니저 초기화
            if (class_exists('AINL_Email_Manager')) {
                new AINL_Email_Manager();
            }
            
            // 템플릿 관리자 초기화
            if (class_exists('AINL_Template_Manager')) {
                new AINL_Template_Manager();
            }
            
            // 캠페인 관리자 초기화
            if (class_exists('AINL_Campaign_Manager')) {
                new AINL_Campaign_Manager();
            }
            
            // 구독 폼 시스템 초기화
            if (class_exists('AINL_Subscription_Form')) {
                AINL_Subscription_Form::get_instance();
            }
            
            // 통계 시스템 초기화
            if (class_exists('AINL_Statistics')) {
                AINL_Statistics::get_instance();
            }
            
            // GDPR 컴플라이언스 시스템 초기화
            if (class_exists('AINL_GDPR')) {
                AINL_GDPR::get_instance();
            }
            
            // AI 엔진 초기화
            if (class_exists('AINL_AI_Engine')) {
                AINL_AI_Engine::get_instance();
            }
            
            // 관리자 인터페이스 초기화 (지연 로딩)
            if (is_admin()) {
                // 관리자 메뉴는 AINL_Admin 클래스 내부에서 처리하므로 여기서는 클래스만 초기화
                $admin_file = AINL_PLUGIN_DIR . 'admin/class-ainl-admin.php';
                if (file_exists($admin_file)) {
                    require_once $admin_file;
                    if (class_exists('AINL_Admin') && function_exists('current_user_can') && current_user_can('manage_options')) {
                        new AINL_Admin();
                    }
                } else {
                    if (function_exists('error_log')) {
                        error_log('AI Newsletter Generator Pro: Admin 파일을 찾을 수 없습니다: ' . $admin_file);
                    }
                }
                
                if (class_exists('AINL_Settings')) {
                    new AINL_Settings();
                }
            }
            
        } catch (Exception $e) {
            // 오류 로깅 (WordPress 오류 로그에 기록)
            if (function_exists('error_log')) {
                error_log('AI Newsletter Generator Pro 초기화 오류: ' . $e->getMessage());
            }
            
            // 관리자에게 알림 표시
            if (function_exists('is_admin') && is_admin() && function_exists('add_action')) {
                add_action('admin_notices', function() use ($e) {
                    $message = function_exists('esc_html') ? esc_html($e->getMessage()) : $e->getMessage();
                    echo '<div class="notice notice-error"><p><strong>AI Newsletter Generator Pro:</strong> 플러그인 초기화 중 오류가 발생했습니다. 오류: ' . $message . '</p></div>';
                });
            }
        }
    }
    
    /**
     * 사용자 정의 크론 스케줄 추가
     * 이메일 큐 처리를 위한 매분 실행 스케줄을 추가합니다.
     * 
     * @param array $schedules 기존 크론 스케줄 배열
     * @return array 수정된 크론 스케줄 배열
     */
    public function add_cron_schedules($schedules) {
        // 매분 실행 스케줄 추가
        $schedules['every_minute'] = array(
            'interval' => 60, // 60초 = 1분
            'display'  => __('Every Minute', 'ai-newsletter-generator-pro')
        );
        
        // 5분마다 실행 스케줄 추가
        $schedules['every_five_minutes'] = array(
            'interval' => 300, // 300초 = 5분
            'display'  => __('Every 5 Minutes', 'ai-newsletter-generator-pro')
        );
        
        // 15분마다 실행 스케줄 추가
        $schedules['every_fifteen_minutes'] = array(
            'interval' => 900, // 900초 = 15분
            'display'  => __('Every 15 Minutes', 'ai-newsletter-generator-pro')
        );
        
        return $schedules;
    }
    
    /**
     * 플러그인 활성화 시 실행
     */
    public function activate() {
        // 활성화 처리 클래스 실행
        AINL_Activator::activate();
        
        // 활성화 플래그 설정
        update_option('ainl_plugin_activated', true);
        
        // 버전 정보 저장
        update_option('ainl_plugin_version', AINL_PLUGIN_VERSION);
    }
    
    /**
     * 플러그인 비활성화 시 실행
     */
    public function deactivate() {
        // 비활성화 처리 클래스 실행
        AINL_Deactivator::deactivate();
        
        // 활성화 플래그 제거
        delete_option('ainl_plugin_activated');
    }
    
    /**
     * 플러그인 삭제 시 실행 (정적 메서드)
     */
    public static function uninstall() {
        // 완전한 데이터 정리 (사용자 데이터 포함)
        
        // deactivator를 통한 긴급 정리 실행
        if (class_exists('AINL_Deactivator')) {
            AINL_Deactivator::emergency_cleanup();
        }
        
        // 모든 플러그인 옵션 삭제
        $options_to_delete = array(
            'ainl_plugin_activated',
            'ainl_plugin_version',
            'ainl_settings',
            'ainl_db_version',
            'ainl_api_keys',
            'ainl_email_settings',
            'ainl_template_settings',
            'ainl_gdpr_settings',
            'ainl_subscription_form_settings',
            'ainl_campaign_defaults',
            'ainl_activation_logs',
            'ainl_plugin_deactivated_time',
            'ainl_admin_notice_welcome',
            'ainl_admin_notice_api_key_missing',
            'ainl_admin_notice_database_update',
            'ainl_admin_notice_dismissed',
        );
        
        foreach ($options_to_delete as $option) {
            delete_option($option);
        }
        
        // 데이터베이스 테이블 삭제 (주의: 사용자 데이터 포함)
        if (class_exists('AINL_Database')) {
            // 테이블 삭제는 별도 확인이 필요할 수 있음
            // AINL_Database::drop_all_tables(); // 구현 예정
        }
        
        // 업로드된 파일들 정리
        $upload_dir = wp_upload_dir();
        $plugin_upload_dir = $upload_dir['basedir'] . '/ai-newsletter-files/';
        if (is_dir($plugin_upload_dir)) {
            // 재귀적으로 디렉토리 및 파일 삭제
            self::recursive_rmdir($plugin_upload_dir);
        }
    }
    
    /**
     * 디렉토리를 재귀적으로 삭제하는 헬퍼 메서드
     */
    private static function recursive_rmdir($dir) {
        if (!is_dir($dir)) {
            return false;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            if (is_dir($path)) {
                self::recursive_rmdir($path);
            } else {
                unlink($path);
            }
        }
        
        return rmdir($dir);
    }
}

/**
 * 플러그인 인스턴스 시작
 */
function ainl_get_instance() {
    return AI_Newsletter_Generator_Pro::get_instance();
}

// 플러그인 시작
ainl_get_instance(); 